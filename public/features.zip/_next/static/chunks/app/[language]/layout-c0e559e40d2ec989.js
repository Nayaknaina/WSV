(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [3079], {
        7010: function(e, n, t) {
            Promise.resolve().then(t.bind(t, 7614)), Promise.resolve().then(t.t.bind(t, 65469, 23)), Promise.resolve().then(t.t.bind(t, 25327, 23)), Promise.resolve().then(t.bind(t, 16280)), Promise.resolve().then(t.t.bind(t, 87582, 23)), Promise.resolve().then(t.bind(t, 12634)), Promise.resolve().then(t.t.bind(t, 7831, 23)), Promise.resolve().then(t.t.bind(t, 88383, 23)), Promise.resolve().then(t.t.bind(t, 1838, 23)), Promise.resolve().then(t.t.bind(t, 11951, 23)), Promise.resolve().then(t.bind(t, 68744)), Promise.resolve().then(t.t.bind(t, 81088, 23)), Promise.resolve().then(t.bind(t, 22547)), Promise.resolve().then(t.bind(t, 47393)), Promise.resolve().then(t.bind(t, 2846)), Promise.resolve().then(t.bind(t, 29140)), Promise.resolve().then(t.bind(t, 13324)), Promise.resolve().then(t.bind(t, 48455)), Promise.resolve().then(t.bind(t, 77607)), Promise.resolve().then(t.bind(t, 12097)), Promise.resolve().then(t.bind(t, 57320)), Promise.resolve().then(t.bind(t, 10400)), Promise.resolve().then(t.bind(t, 60095)), Promise.resolve().then(t.bind(t, 79492)), Promise.resolve().then(t.bind(t, 37391)), Promise.resolve().then(t.bind(t, 19730)), Promise.resolve().then(t.bind(t, 40081)), Promise.resolve().then(t.bind(t, 58358)), Promise.resolve().then(t.t.bind(t, 75376, 23)), Promise.resolve().then(t.t.bind(t, 69667, 23)), Promise.resolve().then(t.t.bind(t, 96677, 23)), Promise.resolve().then(t.t.bind(t, 28534, 23)), Promise.resolve().then(t.t.bind(t, 64153, 23)), Promise.resolve().then(t.t.bind(t, 27870, 23)), Promise.resolve().then(t.t.bind(t, 96874, 23)), Promise.resolve().then(t.t.bind(t, 62725, 23)), Promise.resolve().then(t.t.bind(t, 41965, 23)), Promise.resolve().then(t.t.bind(t, 6474, 23)), Promise.resolve().then(t.t.bind(t, 71960, 23)), Promise.resolve().then(t.t.bind(t, 68290, 23)), Promise.resolve().then(t.t.bind(t, 74109, 23)), Promise.resolve().then(t.t.bind(t, 79372, 23)), Promise.resolve().then(t.t.bind(t, 80417, 23)), Promise.resolve().then(t.t.bind(t, 88563, 23)), Promise.resolve().then(t.t.bind(t, 84693, 23)), Promise.resolve().then(t.t.bind(t, 98711, 23)), Promise.resolve().then(t.t.bind(t, 24477, 23)), Promise.resolve().then(t.t.bind(t, 28176, 23)), Promise.resolve().then(t.t.bind(t, 29949, 23)), Promise.resolve().then(t.t.bind(t, 83494, 23)), Promise.resolve().then(t.t.bind(t, 66504, 23)), Promise.resolve().then(t.t.bind(t, 21019, 23)), Promise.resolve().then(t.t.bind(t, 90483, 23)), Promise.resolve().then(t.t.bind(t, 66899, 23)), Promise.resolve().then(t.t.bind(t, 18207, 23)), Promise.resolve().then(t.t.bind(t, 11159, 23)), Promise.resolve().then(t.t.bind(t, 16658, 23)), Promise.resolve().then(t.t.bind(t, 25681, 23)), Promise.resolve().then(t.t.bind(t, 83674, 23)), Promise.resolve().then(t.t.bind(t, 69077, 23)), Promise.resolve().then(t.t.bind(t, 38431, 23)), Promise.resolve().then(t.t.bind(t, 40385, 23)), Promise.resolve().then(t.t.bind(t, 81783, 23)), Promise.resolve().then(t.t.bind(t, 95583, 23)), Promise.resolve().then(t.t.bind(t, 66666, 23)), Promise.resolve().then(t.t.bind(t, 15757, 23)), Promise.resolve().then(t.t.bind(t, 93615, 23)), Promise.resolve().then(t.t.bind(t, 65974, 23)), Promise.resolve().then(t.t.bind(t, 14234, 23)), Promise.resolve().then(t.t.bind(t, 78330, 23)), Promise.resolve().then(t.t.bind(t, 17114, 23)), Promise.resolve().then(t.t.bind(t, 72603, 23)), Promise.resolve().then(t.t.bind(t, 47214, 23)), Promise.resolve().then(t.t.bind(t, 26313, 23)), Promise.resolve().then(t.t.bind(t, 18885, 23)), Promise.resolve().then(t.t.bind(t, 52961, 23)), Promise.resolve().then(t.t.bind(t, 89532, 23)), Promise.resolve().then(t.t.bind(t, 42686, 23)), Promise.resolve().then(t.t.bind(t, 11600, 23)), Promise.resolve().then(t.t.bind(t, 6155, 23)), Promise.resolve().then(t.t.bind(t, 17415, 23)), Promise.resolve().then(t.t.bind(t, 88492, 23)), Promise.resolve().then(t.t.bind(t, 75929, 23)), Promise.resolve().then(t.t.bind(t, 2443, 23)), Promise.resolve().then(t.t.bind(t, 26817, 23)), Promise.resolve().then(t.t.bind(t, 67623, 23)), Promise.resolve().then(t.t.bind(t, 39289, 23)), Promise.resolve().then(t.t.bind(t, 93307, 23)), Promise.resolve().then(t.t.bind(t, 57973, 23)), Promise.resolve().then(t.t.bind(t, 34692, 23)), Promise.resolve().then(t.t.bind(t, 94528, 23)), Promise.resolve().then(t.t.bind(t, 79121, 23)), Promise.resolve().then(t.t.bind(t, 32031, 23)), Promise.resolve().then(t.t.bind(t, 75134, 23)), Promise.resolve().then(t.t.bind(t, 50807, 23)), Promise.resolve().then(t.t.bind(t, 71461, 23)), Promise.resolve().then(t.t.bind(t, 18757, 23)), Promise.resolve().then(t.t.bind(t, 44748, 23)), Promise.resolve().then(t.t.bind(t, 60150, 23)), Promise.resolve().then(t.t.bind(t, 97454, 23)), Promise.resolve().then(t.t.bind(t, 96244, 23)), Promise.resolve().then(t.t.bind(t, 46886, 23)), Promise.resolve().then(t.t.bind(t, 79425, 23)), Promise.resolve().then(t.t.bind(t, 35877, 23)), Promise.resolve().then(t.t.bind(t, 83362, 23)), Promise.resolve().then(t.t.bind(t, 466, 23)), Promise.resolve().then(t.t.bind(t, 20525, 23)), Promise.resolve().then(t.t.bind(t, 25132, 23)), Promise.resolve().then(t.t.bind(t, 87806, 23)), Promise.resolve().then(t.t.bind(t, 33840, 23)), Promise.resolve().then(t.t.bind(t, 7516, 23)), Promise.resolve().then(t.t.bind(t, 11590, 23)), Promise.resolve().then(t.t.bind(t, 86398, 23)), Promise.resolve().then(t.t.bind(t, 91407, 23)), Promise.resolve().then(t.t.bind(t, 56428, 23)), Promise.resolve().then(t.t.bind(t, 70366, 23)), Promise.resolve().then(t.t.bind(t, 87557, 23)), Promise.resolve().then(t.t.bind(t, 99812, 23)), Promise.resolve().then(t.t.bind(t, 31504, 23)), Promise.resolve().then(t.t.bind(t, 3532, 23)), Promise.resolve().then(t.t.bind(t, 50590, 23)), Promise.resolve().then(t.t.bind(t, 31874, 23)), Promise.resolve().then(t.t.bind(t, 92640, 23)), Promise.resolve().then(t.t.bind(t, 34013, 23)), Promise.resolve().then(t.t.bind(t, 6651, 23)), Promise.resolve().then(t.t.bind(t, 11384, 23)), Promise.resolve().then(t.t.bind(t, 55147, 23)), Promise.resolve().then(t.t.bind(t, 78207, 23)), Promise.resolve().then(t.t.bind(t, 72165, 23)), Promise.resolve().then(t.t.bind(t, 68890, 23)), Promise.resolve().then(t.t.bind(t, 33627, 23)), Promise.resolve().then(t.t.bind(t, 12578, 23)), Promise.resolve().then(t.t.bind(t, 46305, 23)), Promise.resolve().then(t.t.bind(t, 97157, 23)), Promise.resolve().then(t.t.bind(t, 89424, 23)), Promise.resolve().then(t.t.bind(t, 37133, 23)), Promise.resolve().then(t.t.bind(t, 64288, 23)), Promise.resolve().then(t.t.bind(t, 18087, 23)), Promise.resolve().then(t.t.bind(t, 16312, 23)), Promise.resolve().then(t.t.bind(t, 86593, 23)), Promise.resolve().then(t.t.bind(t, 67417, 23)), Promise.resolve().then(t.t.bind(t, 18891, 23)), Promise.resolve().then(t.t.bind(t, 28834, 23)), Promise.resolve().then(t.t.bind(t, 4711, 23)), Promise.resolve().then(t.t.bind(t, 83964, 23)), Promise.resolve().then(t.t.bind(t, 39332, 23)), Promise.resolve().then(t.t.bind(t, 17542, 23)), Promise.resolve().then(t.t.bind(t, 77208, 23)), Promise.resolve().then(t.t.bind(t, 14087, 23)), Promise.resolve().then(t.t.bind(t, 56278, 23)), Promise.resolve().then(t.t.bind(t, 84591, 23)), Promise.resolve().then(t.t.bind(t, 42171, 23)), Promise.resolve().then(t.t.bind(t, 26691, 23)), Promise.resolve().then(t.t.bind(t, 77589, 23)), Promise.resolve().then(t.t.bind(t, 35114, 23)), Promise.resolve().then(t.t.bind(t, 88918, 23)), Promise.resolve().then(t.t.bind(t, 66257, 23)), Promise.resolve().then(t.t.bind(t, 8830, 23)), Promise.resolve().then(t.t.bind(t, 30720, 23)), Promise.resolve().then(t.t.bind(t, 56859, 23)), Promise.resolve().then(t.t.bind(t, 56215, 23)), Promise.resolve().then(t.t.bind(t, 7618, 23)), Promise.resolve().then(t.t.bind(t, 11270, 23)), Promise.resolve().then(t.t.bind(t, 22906, 23)), Promise.resolve().then(t.t.bind(t, 18394, 23)), Promise.resolve().then(t.t.bind(t, 92954, 23)), Promise.resolve().then(t.t.bind(t, 98339, 23)), Promise.resolve().then(t.t.bind(t, 59987, 23)), Promise.resolve().then(t.t.bind(t, 26259, 23)), Promise.resolve().then(t.t.bind(t, 3735, 23)), Promise.resolve().then(t.t.bind(t, 18250, 23)), Promise.resolve().then(t.t.bind(t, 96538, 23)), Promise.resolve().then(t.t.bind(t, 79748, 23)), Promise.resolve().then(t.t.bind(t, 8627, 23)), Promise.resolve().then(t.t.bind(t, 65877, 23)), Promise.resolve().then(t.t.bind(t, 47613, 23)), Promise.resolve().then(t.t.bind(t, 90150, 23)), Promise.resolve().then(t.t.bind(t, 32372, 23)), Promise.resolve().then(t.t.bind(t, 27975, 23)), Promise.resolve().then(t.t.bind(t, 53750, 23)), Promise.resolve().then(t.t.bind(t, 80223, 23)), Promise.resolve().then(t.t.bind(t, 78600, 23)), Promise.resolve().then(t.t.bind(t, 49745, 23)), Promise.resolve().then(t.t.bind(t, 4525, 23)), Promise.resolve().then(t.t.bind(t, 60279, 23)), Promise.resolve().then(t.t.bind(t, 91388, 23)), Promise.resolve().then(t.t.bind(t, 56077, 23)), Promise.resolve().then(t.t.bind(t, 29203, 23)), Promise.resolve().then(t.t.bind(t, 59413, 23)), Promise.resolve().then(t.t.bind(t, 56210, 23)), Promise.resolve().then(t.t.bind(t, 27193, 23)), Promise.resolve().then(t.t.bind(t, 65209, 23)), Promise.resolve().then(t.t.bind(t, 75363, 23)), Promise.resolve().then(t.t.bind(t, 11558, 23)), Promise.resolve().then(t.t.bind(t, 15130, 23)), Promise.resolve().then(t.t.bind(t, 60941, 23)), Promise.resolve().then(t.t.bind(t, 50198, 23)), Promise.resolve().then(t.t.bind(t, 9937, 23)), Promise.resolve().then(t.t.bind(t, 21588, 23)), Promise.resolve().then(t.t.bind(t, 60046, 23)), Promise.resolve().then(t.t.bind(t, 92883, 23)), Promise.resolve().then(t.t.bind(t, 36547, 23)), Promise.resolve().then(t.t.bind(t, 86641, 23)), Promise.resolve().then(t.t.bind(t, 37409, 23)), Promise.resolve().then(t.t.bind(t, 99425, 23)), Promise.resolve().then(t.t.bind(t, 48342, 23)), Promise.resolve().then(t.bind(t, 6889)), Promise.resolve().then(t.bind(t, 39252)), Promise.resolve().then(t.t.bind(t, 27442, 23)), Promise.resolve().then(t.bind(t, 52060)), Promise.resolve().then(t.t.bind(t, 71586, 23)), Promise.resolve().then(t.bind(t, 73099)), Promise.resolve().then(t.bind(t, 51410)), Promise.resolve().then(t.bind(t, 94938)), Promise.resolve().then(t.bind(t, 14535)), Promise.resolve().then(t.bind(t, 27404)), Promise.resolve().then(t.bind(t, 20523)), Promise.resolve().then(t.t.bind(t, 15545, 17)), Promise.resolve().then(t.t.bind(t, 79321, 17)), Promise.resolve().then(t.t.bind(t, 72037, 17)), Promise.resolve().then(t.t.bind(t, 78951, 17)), Promise.resolve().then(t.t.bind(t, 74289, 17)), Promise.resolve().then(t.t.bind(t, 47025, 23)), Promise.resolve().then(t.t.bind(t, 11301, 23)), Promise.resolve().then(t.t.bind(t, 5663, 23)), Promise.resolve().then(t.bind(t, 14678)), Promise.resolve().then(t.bind(t, 81521)), Promise.resolve().then(t.bind(t, 26436)), Promise.resolve().then(t.bind(t, 4645)), Promise.resolve().then(t.bind(t, 70936)), Promise.resolve().then(t.t.bind(t, 22869, 23))
        },
        8292: function(e, n, t) {
            "use strict";
            t.d(n, {
                K: function() {
                    return r
                }
            });
            var o = t(27573);
            t(7653);
            var i = t(15932);
            let r = e => {
                let {
                    children: n,
                    gapSize: t = i.xz.Medium,
                    hasDivider: r
                } = e;
                return (0, o.jsx)(i.aV, {
                    gapSize: t,
                    hasDivider: r,
                    semanticRole: !1,
                    children: n
                })
            }
        },
        14678: function(e, n, t) {
            "use strict";
            t.d(n, {
                default: function() {
                    return z
                }
            });
            var o, i, r, s, l = t(27573),
                d = t(7653),
                a = t(79492),
                c = t(22547),
                h = t(29194),
                m = t(39666),
                v = t(45531),
                b = t.n(v),
                u = t(48567),
                P = t(60580),
                f = t(58832),
                p = t(53944),
                g = t.n(p);
            (o = r || (r = {})).Orange = "orange", o.Turquoise = "turquoise";
            let k = e => {
                let {
                    announcement: n,
                    ctaButton: t,
                    description: o,
                    onCloseCallback: i,
                    testId: r,
                    variant: s = "orange"
                } = e, a = (0, P.G)("announcement-toast-label"), v = (0, P.G)("announcement-toast-description");
                return (0, l.jsxs)("div", {
                    "aria-describedby": o ? v : void 0,
                    "aria-labelledby": a,
                    className: b()({
                        [g().component]: !0,
                        [g().hasOrangeVariant]: "orange" === s,
                        [g().hasTurquoiseVariant]: "turquoise" === s
                    }),
                    "data-testid": r,
                    role: "alert",
                    children: [(0, l.jsx)("div", {
                        className: g().announcement,
                        id: a,
                        children: n
                    }), o && (0, l.jsx)("div", {
                        className: g().description,
                        id: v,
                        children: (0, l.jsx)(m.H, {
                            children: o
                        })
                    }), t && (0, l.jsx)("div", {
                        className: g().ctaButton,
                        children: (0, d.isValidElement)(t) ? t : (0, f.Kn)(t) ? (0, l.jsx)(c.Button, {
                            download: t.download,
                            href: t.href,
                            iconLeft: t.iconLeft,
                            iconRight: t.iconRight,
                            onClick: t.onClick,
                            size: [h.qE.Small, h.qE.Medium],
                            variant: h.Wu.Outline,
                            children: t.label
                        }) : null
                    }), i && (0, l.jsx)("button", {
                        "aria-label": "Close this message",
                        className: g().closeButton,
                        onClick: i,
                        type: "button",
                        children: (0, l.jsx)(u._k, {
                            size: 16,
                            type: u.Rk.Close,
                            variant: u.lC.Normal
                        })
                    })]
                })
            };
            var C = t(67461),
                x = t(26918),
                _ = t(67754),
                j = t(85312),
                y = t(79187),
                w = t(94900),
                E = t(54322);

            function S(e) {
                return "Conductor & Acquia Announce Strategic Partnership" === e ? "announcement-Conductor-&-Acquia-Announce-Strategic-Partnership" : `accouncement-${(0,j.h)(e)}`
            }(i = s || (s = {})).Modal = "modal", i.Toast = "toast";
            var z = e => {
                let {
                    language: n
                } = e, {
                    t
                } = (0, x.E)(n, ["common"]), o = (0, d.useRef)(null), {
                    activeAnnouncement: i,
                    closeAnnouncement: s,
                    isVisible: v
                } = function(e) {
                    let {
                        announcements: n,
                        excludedPages: t
                    } = e, o = (0, _.usePathname)(), [i, r] = (0, d.useState)(null), [s, l] = (0, d.useState)(!1);
                    (0, d.useEffect)(() => {
                        if (!i) {
                            let e = new Date().toISOString(),
                                t = n.find(n => e > n.validFrom && (!n.validTo || e < n.validTo));
                            t && r(t)
                        }
                    }, [n, i]), (0, d.useEffect)(() => {
                        var e, n;
                        if (!y.j || !i) return;
                        let r = S(i.title),
                            s = "announcement-closed" === (0, E.le)(r),
                            d = o === (null === (e = i.link) || void 0 === e ? void 0 : e.href),
                            a = !0 === (0, w.yD)(),
                            c = null !== (n = null == t ? void 0 : t.includes(o)) && void 0 !== n && n;
                        l(a && !s && !d && !c)
                    }, [i, t, o]);
                    let a = (0, d.useCallback)(() => {
                        if (!y.j || !i) return;
                        let e = S(i.title);
                        (0, E.D$)(e, "announcement-closed"), l(!1)
                    }, [i]);
                    return {
                        activeAnnouncement: i,
                        closeAnnouncement: a,
                        isVisible: s
                    }
                }(e);
                return v && i ? (e => {
                    let n = e.backgroundColor === C.YI.OutcomesNeutral ? r.Orange : r.Turquoise;
                    return "modal" === e.variant ? (0, l.jsx)(a.Modal, {
                        actionElements: e.link ? (0, l.jsx)(c.Button, {
                            href: e.link.href,
                            onClick: s,
                            ref: o,
                            size: h.qE.Large,
                            children: e.link.label
                        }) : void 0,
                        closeBtnAriaLabel: t("common.modal.panel.button.close.aria_label"),
                        isClosable: !0,
                        isOpen: v,
                        onCloseCallback: s,
                        variant: n,
                        children: (0, l.jsxs)(m.H, {
                            children: [(0, l.jsx)("h2", {
                                children: e.title
                            }), e.description]
                        })
                    }) : (0, l.jsx)(k, {
                        announcement: e.title,
                        ctaButton: e.link ? (0, l.jsx)(c.Button, {
                            href: e.link.href,
                            onClick: s,
                            size: h.qE.Large,
                            children: e.link.label
                        }) : void 0,
                        description: e.description,
                        onCloseCallback: s,
                        testId: "announcement-toast",
                        variant: n
                    })
                })(i) : null
            }
        },
        26436: function(e, n, t) {
            "use strict";
            t.d(n, {
                default: function() {
                    return R
                }
            });
            var o = t(27573),
                i = t(67754),
                r = t(7653),
                s = t(94900),
                l = t(89026),
                d = t(19237),
                a = t(10214),
                c = t(29039),
                h = t(48567),
                m = t(92640),
                v = t.n(m);
            let b = e => {
                let {
                    closeBtnAriaLabel: n,
                    content: t,
                    isHidden: i,
                    onCloseCallback: r,
                    testId: s
                } = e;
                return i ? null : (0, o.jsx)("div", {
                    "aria-hidden": !0,
                    className: v().wrapper,
                    "data-testid": s,
                    children: (0, o.jsxs)("div", {
                        className: v().component,
                        children: [(0, o.jsx)("div", {
                            className: v().closeButton,
                            children: (0, o.jsx)(c.$D, {
                                "aria-label": n,
                                iconType: h.Rk.Close,
                                onClick: r,
                                variant: c.of.Reversed
                            })
                        }), (0, o.jsx)("div", {
                            className: v().text,
                            children: t
                        })]
                    })
                })
            };
            var u = t(26918),
                P = e => {
                    let {
                        language: n,
                        saveImplicitConsent: t
                    } = e, {
                        t: i
                    } = (0, u.E)(n, ["common"]);
                    (0, r.useEffect)(() => {
                        function e() {
                            (window.pageYOffset || (document.documentElement || document.body.parentNode || document.body).scrollTop) > 100 && (t(), window.removeEventListener("scroll", e))
                        }
                        return window.addEventListener("scroll", e, {
                            passive: !0
                        }), () => {
                            window.removeEventListener("scroll", e)
                        }
                    }, [t]);
                    let s = (0, o.jsx)(a.B, {
                        href: "/legal/cookie-policy/",
                        variant: a.r.Light,
                        children: " cookie policy"
                    });
                    return (0, o.jsx)(b, {
                        closeBtnAriaLabel: i("common.button.close.label"),
                        content: (0, o.jsx)(d.cC, {
                            components: {
                                p1: (0, o.jsx)("p", {}),
                                p2: (0, o.jsx)("p", {}),
                                Link: s
                            },
                            i18nKey: "common.cookie.banner.content",
                            t: i
                        }),
                        onCloseCallback: t,
                        testId: "cookie-banner"
                    })
                },
                f = t(79492),
                p = t(55932),
                g = t(22547),
                k = t(29194),
                C = t(39666),
                x = t(82317),
                _ = e => {
                    let {
                        changeView: n,
                        language: t,
                        rejectConsent: i,
                        saveExplicitConsent: l
                    } = e, {
                        t: a
                    } = (0, u.E)(t, ["components"]), c = (0, r.useRef)(null), h = (0, o.jsx)(x.l, {
                        href: "#",
                        onClick: () => n("policy")
                    }), m = (0, o.jsx)(x.l, {
                        href: "#",
                        onClick: () => n("preferences")
                    });
                    return (0, o.jsx)(f.Modal, {
                        actionElements: (0, o.jsxs)(p.q, {
                            children: [(0, o.jsx)(g.Button, {
                                onClick: () => i(),
                                size: [k.qE.Medium, k.qE.Large],
                                type: k.L$.Submit,
                                variant: k.Wu.Outline,
                                children: a("CookieConsentNotification.button.reject_all.label")
                            }), (0, o.jsx)(g.Button, {
                                onClick: () => n("preferences"),
                                size: [k.qE.Medium, k.qE.Large],
                                variant: k.Wu.Outline,
                                children: a("CookieConsentNotification.button.preferences.label")
                            }), (0, o.jsx)(g.Button, {
                                onClick: () => {
                                    l(s.Aw)
                                },
                                size: [k.qE.Medium, k.qE.Large],
                                type: k.L$.Submit,
                                variant: k.Wu.Outline,
                                children: a("CookieConsentNotification.button.accept_all.label")
                            })]
                        }),
                        initialFocus: () => {
                            var e;
                            return null !== (e = c.current) && void 0 !== e && e
                        },
                        isClosable: !1,
                        isOpen: !0,
                        variant: f.ModalVariant.Lightweight,
                        children: (0, o.jsxs)(C.H, {
                            children: [(0, o.jsx)("h2", {
                                children: a("CookieConsentNotification.title")
                            }), (0, o.jsx)("p", {
                                children: (0, o.jsx)(d.cC, {
                                    components: {
                                        CookiePolicyLink: h,
                                        PreferencesLink: m
                                    },
                                    i18nKey: "CookieConsentNotification.content",
                                    t: a
                                })
                            })]
                        })
                    })
                },
                j = t(1900),
                y = e => {
                    let {
                        changeView: n,
                        cookiePolicyContent: t,
                        language: i
                    } = e, {
                        t: s
                    } = (0, u.E)(i, ["components", "common"]), l = (0, r.useRef)(null);
                    return (0, o.jsx)(f.Modal, {
                        actionElements: (0, o.jsx)(p.q, {
                            children: (0, o.jsx)(g.Button, {
                                onClick: () => n("notification"),
                                ref: l,
                                size: [k.qE.Medium, k.qE.Large],
                                variant: k.Wu.Outline,
                                children: s("common.back", {
                                    ns: "common"
                                })
                            })
                        }),
                        initialFocus: () => {
                            var e;
                            return null !== (e = l.current) && void 0 !== e && e
                        },
                        isClosable: !1,
                        isOpen: !0,
                        variant: f.ModalVariant.Lightweight,
                        children: t ? (0, o.jsxs)(C.H, {
                            children: [(0, o.jsx)("h2", {
                                children: s("CookieConsentPolicy.title.cookie_policy", {
                                    ns: "components"
                                })
                            }), t]
                        }) : (0, o.jsx)(j.T, {})
                    })
                },
                w = t(25687),
                E = t(52155),
                S = t(15130),
                z = t.n(S);
            let L = e => {
                let {
                    children: n,
                    height: t,
                    maxWidth: i
                } = e, [r, s, l] = (0, E.Rp)(t), [d, a, c] = (0, E.Rp)(i), h = {
                    "--container-mobile-height": `${r}px`,
                    "--container-tablet-height": `${s}px`,
                    "--container-desktop-height": `${l}px`,
                    "--container-mobile-max-width": `${d}px`,
                    "--container-tablet-max-width": `${a}px`,
                    "--container-desktop-max-width": `${c}px`
                };
                return (0, o.jsx)("div", {
                    className: z().component,
                    style: h,
                    children: n
                })
            };
            var q = t(8292),
                O = t(15932),
                N = t(29140),
                $ = e => {
                    let {
                        changeView: n,
                        language: t,
                        saveExplicitConsent: i
                    } = e, {
                        t: l
                    } = (0, u.E)(t, ["components"]), d = (0, r.useRef)(null), a = (0, s.JN)(), [c, h] = (0, r.useState)({
                        essentials: !0,
                        statistics: "granted" === a.analytics_storage,
                        marketing: "granted" === a.ad_storage
                    });

                    function m(e) {
                        h({ ...c,
                            [e.target.name]: e.target.checked
                        })
                    }
                    let v = (0, o.jsx)(x.l, {
                        href: "#",
                        onClick: () => n("policy")
                    });
                    return (0, o.jsx)(f.Modal, {
                        actionElements: (0, o.jsx)(p.q, {
                            children: (0, o.jsx)(g.Button, {
                                onClick: function() {
                                    let e = c.essentials ? "granted" : "denied",
                                        n = c.marketing ? "granted" : "denied";
                                    i({
                                        ad_personalization: n,
                                        ad_storage: n,
                                        ad_user_data: n,
                                        analytics_storage: c.statistics ? "granted" : "denied",
                                        functionality_storage: e,
                                        personalization_storage: n,
                                        security_storage: e
                                    })
                                },
                                ref: d,
                                size: [k.qE.Medium, k.qE.Large],
                                type: k.L$.Submit,
                                variant: k.Wu.Highlight,
                                children: "Accept selected"
                            })
                        }),
                        initialFocus: () => {
                            var e;
                            return null !== (e = d.current) && void 0 !== e && e
                        },
                        isClosable: !1,
                        isOpen: !0,
                        variant: f.ModalVariant.Lightweight,
                        children: (0, o.jsxs)(C.H, {
                            children: [(0, o.jsxs)("h2", {
                                children: [" ", l("CookieConsentPreferences.title.preferences")]
                            }), (0, o.jsx)("p", {
                                children: (0, o.jsx)(w.c, {
                                    components: {
                                        CookiePolicyLink: v
                                    },
                                    i18nKey: "CookieConsentPreferences.content",
                                    t: l
                                })
                            }), (0, o.jsx)(L, {
                                maxWidth: 490,
                                children: (0, o.jsx)("form", {
                                    children: (0, o.jsxs)(q.K, {
                                        gapSize: O.xz.Large,
                                        children: [(0, o.jsx)(N.CheckboxField, {
                                            checkedState: c.essentials ? N.CheckboxFieldCheckedState.Checked : N.CheckboxFieldCheckedState.Unchecked,
                                            description: l("CookieConsentPreferences.checkbox.functionality_storage.description"),
                                            label: l("CookieConsentPreferences.checkbox.functionality_storage.label"),
                                            name: "essentials",
                                            readOnly: !0,
                                            size: N.CheckboxFieldSize.Large,
                                            value: "checked"
                                        }), (0, o.jsx)(N.CheckboxField, {
                                            checkedState: c.statistics ? N.CheckboxFieldCheckedState.Checked : N.CheckboxFieldCheckedState.Unchecked,
                                            description: l("CookieConsentPreferences.checkbox.analytics_storage.description"),
                                            label: l("CookieConsentPreferences.checkbox.analytics_storage.label"),
                                            name: "statistics",
                                            onChange: m,
                                            size: N.CheckboxFieldSize.Large,
                                            value: "checked"
                                        }), (0, o.jsx)(N.CheckboxField, {
                                            checkedState: c.marketing ? N.CheckboxFieldCheckedState.Checked : N.CheckboxFieldCheckedState.Unchecked,
                                            description: l("CookieConsentPreferences.checkbox.ad_storage.description"),
                                            label: l("CookieConsentPreferences.checkbox.ad_storage.label"),
                                            name: "marketing",
                                            onChange: m,
                                            size: N.CheckboxFieldSize.Large,
                                            value: "checked"
                                        })]
                                    })
                                })
                            })]
                        })
                    })
                },
                R = e => {
                    let {
                        cookiePolicyContent: n,
                        language: t
                    } = e, d = (0, i.usePathname)(), a = (0, l.D)(), [c, h] = (0, r.useState)(null), m = (0, r.useCallback)(() => {
                        (0, s.Kt)({
                            consents: s.Aw,
                            explicit: !1,
                            url: null != d ? d : ""
                        }), h(null)
                    }, [d]), v = (0, r.useCallback)(e => {
                        (0, s.Kt)({
                            consents: e,
                            explicit: !0,
                            url: null != d ? d : ""
                        }), h(null)
                    }, [d]), b = (0, r.useCallback)(() => {
                        (0, s.Kt)({
                            consents: s.Hd,
                            explicit: !0,
                            url: null != d ? d : ""
                        }), h(null)
                    }, [d]);
                    switch ((0, r.useEffect)(() => {
                        (0, s.Xj)() || null === a || h(e => null !== e ? e : a.isGdprCountry && !(0, s.Xj)() ? "notification" : (0, s.yD)() ? null : "banner")
                    }, [a]), c) {
                        case "banner":
                            return (0, o.jsx)(P, {
                                language: t,
                                saveImplicitConsent: m
                            });
                        case "notification":
                            return (0, o.jsx)(_, {
                                changeView: h,
                                language: t,
                                rejectConsent: b,
                                saveExplicitConsent: v
                            });
                        case "preferences":
                            return (0, o.jsx)($, {
                                changeView: h,
                                language: t,
                                saveExplicitConsent: v
                            });
                        case "policy":
                            return (0, o.jsx)(y, {
                                changeView: h,
                                cookiePolicyContent: n,
                                language: t
                            });
                        default:
                            return null
                    }
                }
        },
        94900: function(e, n, t) {
            "use strict";
            t.d(n, {
                Aw: function() {
                    return d
                },
                Hd: function() {
                    return l
                },
                JN: function() {
                    return c
                },
                Kt: function() {
                    return a
                },
                Xj: function() {
                    return m
                },
                yD: function() {
                    return h
                }
            });
            var o = t(92196),
                i = t(79187),
                r = t(17098),
                s = t(54322);
            let l = {
                    ad_personalization: "denied",
                    ad_storage: "denied",
                    ad_user_data: "denied",
                    analytics_storage: "denied",
                    functionality_storage: "denied",
                    personalization_storage: "denied",
                    security_storage: "denied"
                },
                d = {
                    ad_personalization: "granted",
                    ad_storage: "granted",
                    ad_user_data: "granted",
                    analytics_storage: "granted",
                    functionality_storage: "granted",
                    personalization_storage: "granted",
                    security_storage: "granted"
                };

            function a(e) {
                var n;
                let {
                    consents: t,
                    explicit: l,
                    url: d
                } = e;
                if (!i.j) throw Error("Consent can only be saved in the browser");
                let a = (0, s.le)(r.O.cookieConsentStorageKey()),
                    c = null !== (n = null == a ? void 0 : a.id) && void 0 !== n ? n : (0, o.x0)();
                try {
                    (0, s.D$)(r.O.cookieConsentStorageKey(), {
                        consents: t,
                        id: c,
                        explicit: l
                    }), gtag("consent", "update", t), window.dataLayer.push({
                        event: "consent-update"
                    })
                } catch (e) {
                    console.error("Failed to update cookie consent in gtm", e)
                }
                fetch("/api/record-cookie-consent/", {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json"
                    },
                    body: JSON.stringify({
                        consents: t,
                        explicit: l,
                        url: d,
                        id: c,
                        date: new Date
                    })
                })
            }

            function c() {
                var e, n, t, o, d, c, h, m, v;
                if (!i.j) return l;
                let b = (0, s.le)(r.O.cookieConsentStorageKey());
                return (null == b ? void 0 : b.consents) ? void 0 === b.consents.ad_personalization || void 0 === b.consents.ad_user_data ? (b.consents.ad_personalization = null !== (e = b.consents.ad_personalization) && void 0 !== e ? e : "granted", b.consents.ad_user_data = null !== (n = b.consents.ad_user_data) && void 0 !== n ? n : "granted", a({
                    consents: b.consents,
                    explicit: b.explicit,
                    url: window.location.href
                }), b.consents) : {
                    ad_personalization: null !== (t = b.consents.ad_personalization) && void 0 !== t ? t : "denied",
                    ad_storage: null !== (o = b.consents.ad_storage) && void 0 !== o ? o : "denied",
                    ad_user_data: null !== (d = b.consents.ad_user_data) && void 0 !== d ? d : "denied",
                    analytics_storage: null !== (c = b.consents.analytics_storage) && void 0 !== c ? c : "denied",
                    functionality_storage: null !== (h = b.consents.functionality_storage) && void 0 !== h ? h : "granted",
                    personalization_storage: null !== (m = b.consents.personalization_storage) && void 0 !== m ? m : "denied",
                    security_storage: null !== (v = b.consents.security_storage) && void 0 !== v ? v : "granted"
                } : l
            }

            function h() {
                if (!i.j) throw Error("Consent can only be checked in the browser");
                return null !== (0, s.le)(r.O.cookieConsentStorageKey())
            }

            function m() {
                if (!i.j) throw Error("Consent can only be checked in the browser");
                let e = (0, s.le)(r.O.cookieConsentStorageKey());
                return (null == e ? void 0 : e.explicit) === !0
            }
        },
        5663: function() {},
        11301: function() {},
        22869: function() {},
        53944: function(e) {
            e.exports = {
                component: "AnnouncementToast_component__gRYa_",
                hasOrangeVariant: "AnnouncementToast_hasOrangeVariant__Zvl6u",
                hasTurquoiseVariant: "AnnouncementToast_hasTurquoiseVariant__NgBcu",
                announcement: "AnnouncementToast_announcement__Sy99b",
                description: "AnnouncementToast_description__RipID",
                ctaButton: "AnnouncementToast_ctaButton__fvIxP",
                closeButton: "AnnouncementToast_closeButton__CE8LS"
            }
        },
        7614: function(e, n, t) {
            "use strict";
            t.d(n, {
                SpeedInsights: function() {
                    return v
                }
            });
            var o = t(7653),
                i = t(67754),
                r = () => {
                    window.si || (window.si = function() {
                        for (var e = arguments.length, n = Array(e), t = 0; t < e; t++) n[t] = arguments[t];
                        (window.siq = window.siq || []).push(n)
                    })
                };

            function s() {
                return false
            }
            var l = "https://va.vercel-scripts.com/v1/speed-insights",
                d = `${l}/script.js`,
                a = `${l}/script.debug.js`;

            function c(e) {
                let n = (0, o.useRef)(null);
                return (0, o.useEffect)(() => {
                    if (n.current) e.route && n.current(e.route);
                    else {
                        let t = function() {
                            var e;
                            let n = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
                            if (!("undefined" != typeof window) || null === n.route) return null;
                            r();
                            let t = !!n.dsn,
                                o = n.scriptSrc || (t ? d : "/_vercel/speed-insights/script.js");
                            if (document.head.querySelector(`script[src*="${o}"]`)) return null;
                            n.beforeSend && (null == (e = window.si) || e.call(window, "beforeSend", n.beforeSend));
                            let i = document.createElement("script");
                            return i.src = o, i.defer = !0, i.dataset.sdkn = "@vercel/speed-insights" + (n.framework ? `/${n.framework}` : ""), i.dataset.sdkv = "1.0.10", n.sampleRate && (i.dataset.sampleRate = n.sampleRate.toString()), n.route && (i.dataset.route = n.route), n.endpoint && (i.dataset.endpoint = n.endpoint), n.dsn && (i.dataset.dsn = n.dsn), i.onerror = () => {
                                console.log(`[Vercel Speed Insights] Failed to load script from ${o}. Please check if any content blockers are enabled and try again.`)
                            }, document.head.appendChild(i), {
                                setRoute: e => {
                                    i.dataset.route = null != e ? e : void 0
                                }
                            }
                        }({
                            framework: e.framework || "react",
                            ...e
                        });
                        t && (n.current = t.setRoute)
                    }
                }, [e.route]), null
            }
            var h = () => {
                let e = (0, i.useParams)(),
                    n = (0, i.useSearchParams)(),
                    t = (0, i.usePathname)(),
                    o = { ...Object.fromEntries(n.entries()),
                        ...e || {}
                    };
                return e ? function(e, n) {
                    if (!e || !n) return e;
                    let t = e;
                    try {
                        for (let [e, o] of Object.entries(n)) {
                            let n = Array.isArray(o),
                                i = n ? o.join("/") : o,
                                r = n ? `...${e}` : e,
                                s = RegExp(`/${i.replace(/[.*+?^${}()|[\]\\]/g,"\\$&")}(?=[/?#]|$)`);
                            s.test(t) && (t = t.replace(s, `/[${r}]`))
                        }
                        return t
                    } catch (n) {
                        return e
                    }
                }(t, o) : null
            };

            function m(e) {
                let n = h();
                return o.createElement(c, {
                    route: n,
                    ...e,
                    framework: "next"
                })
            }

            function v(e) {
                return o.createElement(o.Suspense, {
                    fallback: null
                }, o.createElement(m, { ...e
                }))
            }
        }
    },
    function(e) {
        e.O(0, [4027, 1846, 6344, 4854, 8890, 3156, 1126, 1222, 4993, 5203, 281, 6381, 6302, 4235, 3266, 8538, 7645, 9949, 4200, 1293, 5162, 1744], function() {
            return e(e.s = 7010)
        }), _N_E = e.O()
    }
]);