(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [7645], {
        81781: function(e, a, n) {
            "use strict";
            var l, i;
            n.d(a, {
                i: function() {
                    return l
                }
            }), (i = l || (l = {})).BookADemo = "book-a-demo", i.Default = "default", i.Newsletter = "newsletter"
        },
        13324: function(e, a, n) {
            "use strict";
            n.r(a), n.d(a, {
                MarketoForm: function() {
                    return g
                }
            });
            var l = n(27573),
                i = n(45531),
                t = n.n(i),
                r = n(7653);
            let u = [{
                    key: "Germany",
                    value: "Deutschland"
                }, {
                    key: "Austria",
                    value: "\xd6sterreich"
                }, {
                    key: "Switzerland",
                    value: "Schweiz"
                }, {
                    key: "Afghanistan",
                    value: "Afghanistan"
                }, {
                    key: "Egypt",
                    value: "\xc4gypten"
                }, {
                    key: "Aland Islands",
                    value: "Aland"
                }, {
                    key: "Aland Islands",
                    value: "Aland"
                }, {
                    key: "Albania",
                    value: "Albanien"
                }, {
                    key: "Algeria",
                    value: "Algerien"
                }, {
                    key: "American Samoa",
                    value: "Amerikanisch-Samoa"
                }, {
                    key: "Andorra",
                    value: "Andorra"
                }, {
                    key: "Angola",
                    value: "Angola"
                }, {
                    key: "Anguilla",
                    value: "Anguilla"
                }, {
                    key: "Antarctica",
                    value: "Antarktis"
                }, {
                    key: "Antigua and Barbuda",
                    value: "Antigua und Barbuda"
                }, {
                    key: "Equatorial Guinea",
                    value: "\xc4quatorialguinea"
                }, {
                    key: "Argentina",
                    value: "Argentinien"
                }, {
                    key: "Armenia",
                    value: "Armenie"
                }, {
                    key: "Aruba",
                    value: "Aruba"
                }, {
                    key: "Azerbaijan",
                    value: "Aserbaidschan"
                }, {
                    key: "Ethiopia",
                    value: "\xc4thiopien"
                }, {
                    key: "Australia",
                    value: "Australien"
                }, {
                    key: "Bahamas",
                    value: "Bahamas"
                }, {
                    key: "Bahrain",
                    value: "Bahrain"
                }, {
                    key: "Bangladesh",
                    value: "Bangladesch"
                }, {
                    key: "Barbados",
                    value: "Barbados"
                }, {
                    key: "Belgium",
                    value: "Belgien"
                }, {
                    key: "Belize",
                    value: "Belize"
                }, {
                    key: "Benin",
                    value: "Benin"
                }, {
                    key: "Bermuda",
                    value: "Bermuda"
                }, {
                    key: "Bhutan",
                    value: "Bhutan"
                }, {
                    key: "Bolivia, Plurinational State of",
                    value: "Bolivien"
                }, {
                    key: "Bonaire, Sint Eustatius and Saba",
                    value: "Bonaire, Sint Eustatius und Saba"
                }, {
                    key: "Bosnia and Herzegovina",
                    value: "Bosnien und Herzegowina"
                }, {
                    key: "Botswana",
                    value: "Botswana"
                }, {
                    key: "Brazil",
                    value: "Brasilien"
                }, {
                    key: "British Indian Ocean Territory",
                    value: "Britisches Territorium im Indischen Ozean"
                }, {
                    key: "Brunei Durussalam",
                    value: "Brunei Durussalam"
                }, {
                    key: "Bulgaria",
                    value: "Bulgarien"
                }, {
                    key: "Burkina Faso",
                    value: "Burkina Fasoo"
                }, {
                    key: "Burundi",
                    value: "Burundi"
                }, {
                    key: "Cayman Islands",
                    value: "Cayman-Inseln"
                }, {
                    key: "Chile",
                    value: "Chile"
                }, {
                    key: "China",
                    value: "China"
                }, {
                    key: "Cocos (Keeling) Islands",
                    value: "Cocos (Keeling) Inseln"
                }, {
                    key: "Cook Islands",
                    value: "Cook-Inseln"
                }, {
                    key: "Costa Rica",
                    value: "Costa Rica"
                }, {
                    key: "Cura\xe7ao",
                    value: "Cura\xe7ao"
                }, {
                    key: "Denmark",
                    value: "D\xe4nemark"
                }, {
                    key: "Congo, the Democratic Republic of the",
                    value: "Demokratische Republik Kongo"
                }, {
                    key: "Korea, Democratic People's Republic of",
                    value: "Demokratische Volksrepublik Korea"
                }, {
                    key: "Lao People's Democratic Republic",
                    value: "Demokratische Volksrepublik Laos"
                }, {
                    key: "Dominica",
                    value: "Dominica"
                }, {
                    key: "Dominican Republic",
                    value: "Dominikanische Republik"
                }, {
                    key: "Djibouti",
                    value: "Dschibutii"
                }, {
                    key: "Ecuador",
                    value: "Ecuador"
                }, {
                    key: "El Salvador",
                    value: "El Salvador"
                }, {
                    key: "Cote d'Ivoire",
                    value: "Elfenbeink\xfcste"
                }, {
                    key: "Eritrea",
                    value: "Eritrea"
                }, {
                    key: "Estonia",
                    value: "Estlan"
                }, {
                    key: "Eswatini",
                    value: "Eswatini"
                }, {
                    key: "Falkland Islands (Malvinas)",
                    value: "Falklandinseln (Malwinen)"
                }, {
                    key: "Faroe Islands",
                    value: "F\xe4r\xf6er Inseln"
                }, {
                    key: "Fiji",
                    value: "Fidschi"
                }, {
                    key: "Finland",
                    value: "Finnland"
                }, {
                    key: "France",
                    value: "Frankreich"
                }, {
                    key: "French Southern Territories",
                    value: "Franz\xf6sische S\xfcdterritorien"
                }, {
                    key: "French Guiana",
                    value: "Franz\xf6sisch-Guayana"
                }, {
                    key: "French Polynesia",
                    value: "Franz\xf6sisch-Polynesien"
                }, {
                    key: "Gabon",
                    value: "Gabun"
                }, {
                    key: "Gambia",
                    value: "Gambia"
                }, {
                    key: "Georgia",
                    value: "Georgien"
                }, {
                    key: "Ghana",
                    value: "Ghana"
                }, {
                    key: "Gibraltar",
                    value: "Gibraltar"
                }, {
                    key: "Grenada",
                    value: "Grenada"
                }, {
                    key: "Greece",
                    value: "Griechenland"
                }, {
                    key: "Greenland",
                    value: "Gr\xf6nland"
                }, {
                    key: "Guadeloupe",
                    value: "Guadeloupe"
                }, {
                    key: "Guam",
                    value: "Guam"
                }, {
                    key: "Guatemala",
                    value: "Guatemala"
                }, {
                    key: "Guernsey",
                    value: "Guernsey"
                }, {
                    key: "Guinea",
                    value: "Guinea"
                }, {
                    key: "Guinea-Bissau",
                    value: "Guinea-Bissau"
                }, {
                    key: "Guyana",
                    value: "Guyana"
                }, {
                    key: "Haiti",
                    value: "Haiti"
                }, {
                    key: "Holy See",
                    value: "Heiliger Stuhl"
                }, {
                    key: "Honduras",
                    value: "Honduras"
                }, {
                    key: "Hong Kong",
                    value: "Hongkong"
                }, {
                    key: "India",
                    value: "Indien"
                }, {
                    key: "Indonesia",
                    value: "Indonesien"
                }, {
                    key: "Iraq",
                    value: "Irak"
                }, {
                    key: "Iran, Islamic Republic of",
                    value: "Iran"
                }, {
                    key: "Ireland",
                    value: "Irland"
                }, {
                    key: "Iceland",
                    value: "Island"
                }, {
                    key: "Isle of Man",
                    value: "Isle of Man"
                }, {
                    key: "Israel",
                    value: "Israel"
                }, {
                    key: "Italy",
                    value: "Italien"
                }, {
                    key: "Jamaica",
                    value: "Jamaika"
                }, {
                    key: "Japan",
                    value: "Japan"
                }, {
                    key: "Yemen",
                    value: "Jemen"
                }, {
                    key: "Jersey",
                    value: "Jersey"
                }, {
                    key: "Jordan",
                    value: "Jordanien"
                }, {
                    key: "Virgin Islands (U.S.)",
                    value: "Jungferninseln (U.S.)"
                }, {
                    key: "Virgin Islands, British",
                    value: "Jungferninseln, Britisch"
                }, {
                    key: "Cambodia",
                    value: "Kambodscha"
                }, {
                    key: "Cameroon",
                    value: "Kamerun"
                }, {
                    key: "Canada",
                    value: "Kanada"
                }, {
                    key: "Cape Verde",
                    value: "Kap Verde"
                }, {
                    key: "Kazakhstan",
                    value: "Kasachstan"
                }, {
                    key: "Qatar",
                    value: "Katar"
                }, {
                    key: "Kenya",
                    value: "Kenia"
                }, {
                    key: "Kyrgyzstan",
                    value: "Kirgisistan"
                }, {
                    key: "Kiribati",
                    value: "Kiribati"
                }, {
                    key: "Colombia",
                    value: "Kolumbien"
                }, {
                    key: "Comoros",
                    value: "Komoren"
                }, {
                    key: "Congo",
                    value: "Kongo"
                }, {
                    key: "Croatia",
                    value: "Kroatien"
                }, {
                    key: "Cuba",
                    value: "Kuba"
                }, {
                    key: "Kuwait",
                    value: "Kuwait"
                }, {
                    key: "Lesotho",
                    value: "Lesotho"
                }, {
                    key: "Latvia",
                    value: "Lettland"
                }, {
                    key: "Lebanon",
                    value: "Libanon"
                }, {
                    key: "Liberia",
                    value: "Liberia"
                }, {
                    key: "Libya",
                    value: "Libyen"
                }, {
                    key: "Liechtenstein",
                    value: "Liechtenstein"
                }, {
                    key: "Lithuania",
                    value: "Litauen"
                }, {
                    key: "Luxembourg",
                    value: "Luxemburg"
                }, {
                    key: "Macao",
                    value: "Macao"
                }, {
                    key: "Madagascar",
                    value: "Madagaskar"
                }, {
                    key: "Malawi",
                    value: "Malawi"
                }, {
                    key: "Malaysia",
                    value: "Malaysia"
                }, {
                    key: "Maldives",
                    value: "Malediven"
                }, {
                    key: "Mali",
                    value: "Mali"
                }, {
                    key: "Malta",
                    value: "Malta"
                }, {
                    key: "Morocco",
                    value: "Marokko"
                }, {
                    key: "Marshall Islands",
                    value: "Marshall-Inseln"
                }, {
                    key: "Martinique",
                    value: "Martinique"
                }, {
                    key: "Mauritania",
                    value: "Mauretanien"
                }, {
                    key: "Mauritius",
                    value: "Mauretanien"
                }, {
                    key: "Mayotte",
                    value: "Mayotte"
                }, {
                    key: "Macedonia, the former Yugoslav Republic of",
                    value: "Mazedonien"
                }, {
                    key: "Mexico",
                    value: "Mexiko"
                }, {
                    key: "Micronesia (Federated States of)",
                    value: "Mikronesien (F\xf6derierte Staaten von)"
                }, {
                    key: "Monaco",
                    value: "Monaco"
                }, {
                    key: "Mongolia",
                    value: "Mongolei"
                }, {
                    key: "Montenegro",
                    value: "Montenegro"
                }, {
                    key: "Montserrat",
                    value: "Montserrat"
                }, {
                    key: "Mozambique",
                    value: "Mosambik"
                }, {
                    key: "Myanmar",
                    value: "Myanmar"
                }, {
                    key: "Namibia",
                    value: "Namibia"
                }, {
                    key: "Nauru",
                    value: "Nauru"
                }, {
                    key: "Nepal",
                    value: "Nepal"
                }, {
                    key: "New Caledonia",
                    value: "Neukaledonien"
                }, {
                    key: "New Zealand",
                    value: "Neuseeland"
                }, {
                    key: "Nicaragua",
                    value: "Nicaragua"
                }, {
                    key: "Netherlands",
                    value: "Niederlande"
                }, {
                    key: "Niger",
                    value: "Niger"
                }, {
                    key: "Nigeria",
                    value: "Nigeria"
                }, {
                    key: "Niue",
                    value: "Niue"
                }, {
                    key: "Northern Mariana Islands",
                    value: "N\xf6rdliche Marianen"
                }, {
                    key: "Norfolk Island",
                    value: "Norfolkinsel"
                }, {
                    key: "Norway",
                    value: "Norwegen"
                }, {
                    key: "Oman",
                    value: "Oman"
                }, {
                    key: "Timor-Leste",
                    value: "Osttimor"
                }, {
                    key: "Pakistan",
                    value: "Pakistan"
                }, {
                    key: "Palestine",
                    value: "Pal\xe4stina"
                }, {
                    key: "Palau",
                    value: "Palau"
                }, {
                    key: "Panama",
                    value: "Panama"
                }, {
                    key: "Papua New Guinea",
                    value: "Papua-Neuguinea"
                }, {
                    key: "Paraguay",
                    value: "Paraguay"
                }, {
                    key: "Peru",
                    value: "Peru"
                }, {
                    key: "Philippines",
                    value: "Philippinen"
                }, {
                    key: "Pitcairn",
                    value: "Pitcairn"
                }, {
                    key: "Poland",
                    value: "Polen"
                }, {
                    key: "Portugal",
                    value: "Portugal"
                }, {
                    key: "Puerto Rico",
                    value: "Puerto Rico"
                }, {
                    key: "Korea, Republic of",
                    value: "Republik Korea"
                }, {
                    key: "Moldova, Republic of",
                    value: "Republik Moldau"
                }, {
                    key: "Reunion",
                    value: "R\xe9union"
                }, {
                    key: "Rwanda",
                    value: "Ruanda"
                }, {
                    key: "Romania",
                    value: "Rum\xe4nien"
                }, {
                    key: "Russia",
                    value: "Russlandd"
                }, {
                    key: "Solomon Islands",
                    value: "Salomon-Inseln"
                }, {
                    key: "Zambia",
                    value: "Sambia"
                }, {
                    key: "Samoa",
                    value: "Samoa"
                }, {
                    key: "San Marino",
                    value: "San Marino"
                }, {
                    key: "Sao Tome and Principe",
                    value: "Sao Tome und Principe"
                }, {
                    key: "Saudi Arabia",
                    value: "Saudi-Arabien"
                }, {
                    key: "Sweden",
                    value: "Schweden"
                }, {
                    key: "Senegal",
                    value: "Senegal"
                }, {
                    key: "Serbia",
                    value: "Serbien"
                }, {
                    key: "Seychelles",
                    value: "Seychellen"
                }, {
                    key: "Sierra Leone",
                    value: "Sierra Leone"
                }, {
                    key: "Zimbabwe",
                    value: "Simbabwe"
                }, {
                    key: "Singapore",
                    value: "Singapur"
                }, {
                    key: "Sint Maarten",
                    value: "Sint Maarten"
                }, {
                    key: "Slovakia",
                    value: "Slowakei"
                }, {
                    key: "Slovenia",
                    value: "Slowenie"
                }, {
                    key: "Somalia",
                    value: "Somalia"
                }, {
                    key: "Spain",
                    value: "Spanien"
                }, {
                    key: "Sri Lanka",
                    value: "Sri Lanka"
                }, {
                    key: "Saint Barth\xe9lemy",
                    value: "St. Barth\xe9lemy"
                }, {
                    key: "Saint Helena, Ascension and Tristan da Cunha",
                    value: "St. Helena, Ascension und Tristan da Cunha"
                }, {
                    key: "Saint Kitts and Nevis",
                    value: "St. Kitts und Nevis"
                }, {
                    key: "Saint Lucia",
                    value: "St. Lucia"
                }, {
                    key: "Saint Martin (French part)",
                    value: "St. Martin (franz\xf6sischer Teil)"
                }, {
                    key: "Saint Pierre and Miquelon",
                    value: "St. Pierre und Miquelon"
                }, {
                    key: "Saint Vincent and the Grenadines",
                    value: "St. Vincent und die Grenadinen"
                }, {
                    key: "South Africa",
                    value: "S\xfcd-Afrika"
                }, {
                    key: "Sudan",
                    value: "Sudan"
                }, {
                    key: "South Sudan",
                    value: "S\xfcdsudan"
                }, {
                    key: "Suriname",
                    value: "Surinam"
                }, {
                    key: "Svalbard and Jan Mayen",
                    value: "Svalbard und Jan Mayen"
                }, {
                    key: "Syrian Arab Republic",
                    value: "Syrische Arabische Republik"
                }, {
                    key: "Tajikistan",
                    value: "Tadschikistan"
                }, {
                    key: "Taiwan",
                    value: "Taiwan"
                }, {
                    key: "Tanzania, the United Republic of",
                    value: "Tansania"
                }, {
                    key: "Thailand",
                    value: "Thailand"
                }, {
                    key: "Togo",
                    value: "Togo"
                }, {
                    key: "Tonga",
                    value: "Tonga"
                }, {
                    key: "Trinidad and Tobago",
                    value: "Trinidad und Tobago"
                }, {
                    key: "Chad",
                    value: "Tschad"
                }, {
                    key: "Czech Republic",
                    value: "Tschechische Republik"
                }, {
                    key: "Tunisia",
                    value: "Tunesien"
                }, {
                    key: "Turkey",
                    value: "T\xfcrkei"
                }, {
                    key: "Turkmenistan",
                    value: "Turkmenistan"
                }, {
                    key: "Turks and Caicos Islands",
                    value: "Turks- und Caicosinseln"
                }, {
                    key: "Tuvalu",
                    value: "Tuvalu"
                }, {
                    key: "Uganda",
                    value: "Uganda"
                }, {
                    key: "Ukraine",
                    value: "Ukraine"
                }, {
                    key: "Hungary",
                    value: "Ungarn"
                }, {
                    key: "Uruguay",
                    value: "Uruguay"
                }, {
                    key: "Uzbekistan",
                    value: "Usbekistan"
                }, {
                    key: "Vanuatu",
                    value: "Vanuatu"
                }, {
                    key: "Venezuela, Bolivarian Republic of",
                    value: "Venezuela"
                }, {
                    key: "United Arab Emirates",
                    value: "Vereinigte Arabische Emirate"
                }, {
                    key: "United States",
                    value: "Vereinigte Staaten"
                }, {
                    key: "United Kingdom",
                    value: "Vereinigtes K\xf6nigreich"
                }, {
                    key: "Vietnam",
                    value: "Vietnam"
                }, {
                    key: "Wallis and Futuna",
                    value: "Wallis und Futuna"
                }, {
                    key: "Belarus",
                    value: "Wei\xdfrussland"
                }, {
                    key: "Western Sahara",
                    value: "Westsahara"
                }, {
                    key: "Central African Republic",
                    value: "Zentralafrikanische Republik"
                }, {
                    key: "Cyprus",
                    value: "Zypern"
                }],
                o = {
                    1070: {
                        de: [{
                            name: "Email",
                            datatype: "text",
                            label: "Gesch\xe4ftliche E-Mail-Adresse:",
                            placeholderText: "Gesch\xe4ftliche E-Mail-Adresse",
                            validationMessage: 'Bitte geben Sie eine g\xfcltige E-Mail-Adresse ein. <span class="mktoErrorDetail">example@yourdomain.com</span>'
                        }, {
                            name: "FirstName",
                            datatype: "text",
                            label: "Vorname:",
                            placeholderText: "Vorname",
                            validationMessage: "Dieses Feld ist erforderlich."
                        }, {
                            name: "LastName",
                            datatype: "text",
                            label: "Nachname:",
                            placeholderText: "Nachname",
                            validationMessage: "Dieses Feld ist erforderlich."
                        }, {
                            name: "Company",
                            datatype: "text",
                            label: "Unternehmensname:",
                            placeholderText: "Unternehmensname",
                            validationMessage: "Dieses Feld ist erforderlich."
                        }, {
                            name: "Employee_Size_Range_CB__c",
                            datatype: "picklist",
                            placeholderText: "Bitte ausw\xe4hlen…",
                            label: "Anzahl der Mitarbeitenden:",
                            validationMessage: "Dieses Feld ist erforderlich."
                        }, {
                            name: "Phone",
                            datatype: "text",
                            label: "Telefonnummer:",
                            placeholderText: "Telefonnummer (optional)"
                        }, {
                            name: "Country",
                            datatype: "picklist",
                            placeholderText: "Bitte ausw\xe4hlen…",
                            label: "Land:",
                            validationMessage: "Dieses Feld ist erforderlich.",
                            options: u
                        }, {
                            name: "Data_Collection_and_Consent__c",
                            datatype: "single_checkbox",
                            label: "Ja, ich w\xfcrde gerne per E-Mail Informationen zu den Produkten und Dienstleistungen von Conductor erhalten. Ich kann mich jederzeit von Werbe-E-Mails abmelden. Weitere Infos in unserer Datenschutzrichtlinie.",
                            validationMessage: "Dieses Feld ist erforderlich."
                        }, {
                            name: "PC_Opt_In__c",
                            datatype: "single_checkbox",
                            label: "Ja, ich w\xfcrde gerne Informationen zu den Produkten und Dienstleistungen von Conductor erhalten und akzeptiere die Datenschutzrichtlinie von Conductor.",
                            validationMessage: "Dieses Feld ist erforderlich."
                        }, {
                            name: "submitButton",
                            datatype: "button",
                            label: "Abschicken"
                        }]
                    },
                    1036: {
                        de: [{
                            name: "Email",
                            datatype: "text",
                            label: "E-Mail-Adresse:",
                            validationMessage: 'Bitte geben Sie eine g\xfcltige E-Mail-Adresse ein. <span class="mktoErrorDetail">example@yourdomain.com</span>'
                        }, {
                            name: "FirstName",
                            datatype: "text",
                            label: "Vorname:",
                            validationMessage: "Dieses Feld ist erforderlich."
                        }, {
                            name: "LastName",
                            datatype: "text",
                            label: "Nachname:",
                            validationMessage: "Dieses Feld ist erforderlich."
                        }, {
                            name: "Title",
                            datatype: "text",
                            label: "Jobbezeichnung:",
                            validationMessage: "Dieses Feld ist erforderlich."
                        }, {
                            name: "Company",
                            datatype: "text",
                            label: "Unternehmensname:",
                            validationMessage: "Dieses Feld ist erforderlich."
                        }, {
                            name: "Website",
                            datatype: "text",
                            label: "Website:",
                            validationMessage: 'Bitte geben Sie eine g\xfcltige Website ein. <span class="mktoErrorDetail">http://www.example.com/</span>'
                        }, {
                            name: "Phone",
                            datatype: "text",
                            label: "Handynummer:",
                            validationMessage: "Dieses Feld ist erforderlich."
                        }, {
                            name: "PC_Opt_In__c",
                            datatype: "single_checkbox",
                            label: " DE PC: Opt-In::",
                            validationMessage: "Dieses Feld ist erforderlich."
                        }, {
                            name: "submitButton",
                            datatype: "button",
                            label: "Jetzt Demo anfragen"
                        }]
                    },
                    2008: {
                        de: [{
                            name: "Email",
                            datatype: "text",
                            label: "Gesch\xe4ftliche E-Mail-Adresse:",
                            placeholderText: "Gesch\xe4ftliche E-Mail-Adresse",
                            validationMessage: 'Bitte geben Sie eine g\xfcltige E-Mail-Adresse ein. <span class="mktoErrorDetail">example@yourdomain.com</span>'
                        }, {
                            name: "FirstName",
                            datatype: "text",
                            label: "Vorname:",
                            placeholderText: "Vorname",
                            validationMessage: "Dieses Feld ist erforderlich."
                        }, {
                            name: "LastName",
                            datatype: "text",
                            label: "Nachname:",
                            placeholderText: "Nachname",
                            validationMessage: "Dieses Feld ist erforderlich."
                        }, {
                            name: "NumberOfEmployees",
                            datatype: "picklist",
                            placeholderText: "Bitte ausw\xe4hlen…",
                            label: "Anzahl der Mitarbeitenden:",
                            validationMessage: "Dieses Feld ist erforderlich."
                        }, {
                            name: "Company",
                            datatype: "text",
                            label: "Unternehmensname:",
                            placeholderText: "Unternehmensname"
                        }, {
                            name: "Phone",
                            datatype: "text",
                            label: "Telefonnummer:",
                            placeholderText: "Telefonnummer (optional)"
                        }, {
                            name: "PC_Opt_In__c",
                            datatype: "single_checkbox",
                            label: "Ja, ich w\xfcrde gerne Informationen zu den Produkten und Dienstleistungen von Conductor erhalten und akzeptiere die Datenschutzrichtlinie von Conductor.",
                            validationMessage: "Dieses Feld ist erforderlich."
                        }, {
                            name: "submitButton",
                            label: "Abschicken",
                            datatype: "button"
                        }]
                    },
                    2010: {
                        de: [{
                            name: "Email",
                            datatype: "text",
                            label: " Gesch\xe4ftliche E-Mail-Adresse:",
                            placeholderText: " Gesch\xe4ftliche E-Mail-Adresse",
                            validationMessage: 'Bitte geben Sie eine g\xfcltige E-Mail-Adresse ein. <span class="mktoErrorDetail">example@yourdomain.com</span>'
                        }, {
                            name: "Country",
                            datatype: "picklist",
                            placeholderText: "Bitte ausw\xe4hlen…",
                            label: "Land:",
                            validationMessage: "Dieses Feld ist erforderlich.",
                            options: u
                        }, {
                            name: "PC_Opt_In__c",
                            datatype: "single_checkbox",
                            label: "Ja, ich w\xfcrde gerne Informationen zu den Produkten und Dienstleistungen von Conductor erhalten und akzeptiere die Datenschutzrichtlinie von Conductor.",
                            validationMessage: "Dieses Feld ist erforderlich."
                        }, {
                            name: "submitButton",
                            datatype: "button",
                            label: "Abschicken"
                        }]
                    }
                };
            var s = n(14535),
                d = n(36809),
                v = n(950),
                k = n(52155),
                y = n(58832),
                c = n(23260),
                m = n(81781),
                h = n(76474),
                p = n.n(h);
            let g = e => {
                let {
                    backgroundContext: a = d.N.Light,
                    children: n = null,
                    defaultValues: i = {},
                    formId: u,
                    language: h = v.SQ.English,
                    marketoBaseUrl: g,
                    minHeight: b,
                    onFinish: f,
                    templateVariant: M = m.i.Default
                } = e, [S, T] = (0, r.useState)(() => () => null), [x, B] = (0, r.useState)(!0), [E, A] = (0, r.useState)(!1), _ = (0, r.useRef)(null), {
                    containerRef: D,
                    translateStaticFormFields: C
                } = function(e, a) {
                    var n;
                    let l = (0, r.useRef)(null),
                        i = (null === (n = o[a]) || void 0 === n ? void 0 : n[e]) ? o[a][e] : void 0;
                    return (0, r.useEffect)(() => {
                        if (!i) return;
                        let e = new MutationObserver(e => {
                            for (let n of e)
                                if ("childList" === n.type && n.addedNodes.length > 0) {
                                    let e = n.addedNodes[0];
                                    if (e instanceof HTMLDivElement && "mktoError" === e.className) {
                                        let n = e.querySelector(".mktoErrorMsg");
                                        if (null == n ? void 0 : n.innerHTML) {
                                            var a;
                                            let e = n.id.substring(8),
                                                l = i.find(a => a.name === e);
                                            n.innerHTML = null !== (a = null == l ? void 0 : l.validationMessage) && void 0 !== a ? a : n.innerHTML
                                        }
                                    }
                                }
                        });
                        return l.current && e.observe(l.current, {
                            childList: !0,
                            subtree: !0
                        }), () => {
                            e.disconnect()
                        }
                    }, [i]), {
                        containerRef: l,
                        translateStaticFormFields: function(e) {
                            var a, n, l, t, r;
                            if (!i) return;
                            let u = e.getElementsByTagName("label");
                            for (let e = 0; e < u.length; e++)
                                if (u[e].innerHTML) {
                                    let n = u[e].htmlFor,
                                        l = i.find(e => e.name === n);
                                    u[e].innerHTML = null !== (a = null == l ? void 0 : l.label) && void 0 !== a ? a : u[e].innerHTML
                                }
                            let o = e.getElementsByTagName("input");
                            for (let e = 0; e < o.length; e++) {
                                let a = o[e].id,
                                    l = i.find(e => e.name === a);
                                o[e].placeholder = null !== (n = null == l ? void 0 : l.placeholderText) && void 0 !== n ? n : o[e].placeholder
                            }
                            let s = e.getElementsByTagName("select");
                            for (let e = 0; e < s.length; e++) {
                                let a = s[e].id,
                                    n = i.find(e => e.name === a),
                                    r = s[e].item(0);
                                if (r && (r.innerText = null !== (l = null == n ? void 0 : n.placeholderText) && void 0 !== l ? l : r.innerText), (null == n ? void 0 : n.options) && s[e].options) {
                                    s[e].options.length = 0;
                                    let a = document.createElement("option");
                                    a.innerText = null !== (t = n.placeholderText) && void 0 !== t ? t : a.innerText, a.value = "", s[e].add(a);
                                    for (let a = 0; a < n.options.length; a++) {
                                        let l = document.createElement("option");
                                        l.value = n.options[a].key, l.innerText = n.options[a].value, s[e].add(l)
                                    }
                                }
                            }
                            let d = e.querySelector("button[type=submit]"),
                                v = i.find(e => "submitButton" === e.name);
                            d.innerText = null !== (r = null == v ? void 0 : v.label) && void 0 !== r ? r : d.innerText
                        }
                    }
                }(h, u), N = (0, r.useMemo)(() => {
                    if (!b) return {};
                    let [e, a, n] = (0, k.tv)(b);
                    return {
                        "--mkto-form-mobile-min-height": `${e}px`,
                        "--mkto-form-tablet-min-height": `${a}px`,
                        "--mkto-form-desktop-min-height": `${n}px`
                    }
                }, [b]), w = (0, r.useCallback)(() => {
                    if (_.current === u) return;
                    let e = window.MktoForms2;
                    _.current = u, e.loadForm(g, "149-ZMU-763", u, e => {
                        let a;
                        let n = e.render()[0],
                            t = e.getValues();
                        for (let a of Object.keys(i)) "" === t[a] && e.setValues({
                            [a]: i[a]
                        });
                        a = 0,
                            function n() {
                                try {
                                    var l, i, t, r, u;
                                    if (a += 1, !(null !== (u = null === (r = window) || void 0 === r ? void 0 : null === (t = r.Clearbit) || void 0 === t ? void 0 : null === (i = t.Enrichment) || void 0 === i ? void 0 : null === (l = i.Marketo) || void 0 === l ? void 0 : l.Forms) && void 0 !== u ? u : []).some(a => a === e) && a < 10) {
                                        setTimeout(n, 500);
                                        return
                                    }
                                    let o = e.getFormElem()[0];
                                    (0, y.h2)(o);
                                    let s = o.querySelector('input[name="Email"]');
                                    (0, y.h2)(s), s.dispatchEvent(new Event("input"))
                                } catch (e) {
                                    console.warn(e)
                                }
                            }(), h === v.SQ.German && C(e.getFormElem()[0]), n.removeAttribute("id"), n.setAttribute("data-formId", u), B(!1), T(() => () => (0, l.jsx)("div", {
                                className: p().form,
                                ref: e => {
                                    (0, y.vT)(e) && (e.innerHTML = "", e.appendChild(n))
                                }
                            })), e.onSuccess(() => (A(!0), null == f || f(), !1))
                    })
                }, [i, u, h, g, f, C]);
                return ((0, s.useExternalScript)(`${g}/js/forms2/js/forms2.min.js`, w), null === n) ? (0, l.jsx)("div", {
                    className: t()({
                        [p().component]: !0,
                        [p().showMessage]: E,
                        [p().hasBookADemoTemplate]: M === m.i.BookADemo,
                        [p().hasNewsletterTemplate]: M === m.i.Newsletter,
                        [p().hasGradientContext]: a === d.N.Gradient
                    }),
                    ref: D,
                    style: N,
                    children: S()
                }) : (0, l.jsx)("div", {
                    className: t()({
                        [p().component]: !0,
                        [p().showMessage]: E,
                        [p().hasBookADemoTemplate]: M === m.i.BookADemo,
                        [p().hasNewsletterTemplate]: M === m.i.Newsletter,
                        [p().hasGradientContext]: a === d.N.Gradient
                    }),
                    ref: D,
                    style: N,
                    children: (0, c.e)(n, {
                        renderForm: S,
                        isActive: !x && !E,
                        isFinished: E,
                        isLoading: x
                    })
                })
            }
        },
        1900: function(e, a, n) {
            "use strict";
            n.d(a, {
                C: function() {
                    return i
                },
                T: function() {
                    return v
                }
            });
            var l, i, t = n(27573),
                r = n(45531),
                u = n.n(r);
            n(7653);
            var o = n(45303),
                s = n(12578),
                d = n.n(s);
            (l = i || (i = {})).Inherit = "inherit", l.Dark = "dark", l.Light = "light";
            let v = e => {
                let {
                    variant: a = "inherit"
                } = e;
                return (0, t.jsxs)("div", {
                    className: u()({
                        [d().component]: !0,
                        [d().isDark]: "dark" === a,
                        [d().isLight]: "light" === a
                    }),
                    children: [(0, t.jsx)("div", {
                        className: d().spinner,
                        children: (0, t.jsx)(o.$, {})
                    }), (0, t.jsx)("div", {
                        className: d().text,
                        children: "Loading..."
                    })]
                })
            }
        },
        94938: function(e, a, n) {
            "use strict";
            n.r(a), n.d(a, {
                useDocumentReadyEffect: function() {
                    return i
                }
            });
            var l = n(7653);

            function i(e, a) {
                (0, l.useEffect)(() => {
                    "complete" === document.readyState ? setTimeout(() => {
                        e()
                    }) : window.addEventListener("load", () => {
                        setTimeout(() => {
                            e()
                        })
                    })
                }, a)
            }
        },
        14535: function(e, a, n) {
            "use strict";
            n.r(a), n.d(a, {
                useExternalScript: function() {
                    return u
                }
            });
            var l = n(7653),
                i = n(94938),
                t = n(27404);
            let r = {};

            function u(e, a) {
                var n, u;
                let [o, s] = (0, l.useState)(null !== (u = null === (n = r[e]) || void 0 === n ? void 0 : n.ready) && void 0 !== u && u), d = (0, t.usePrevious)(o);
                return (0, i.useDocumentReadyEffect)(() => {
                    new Promise((a, n) => {
                        var l;
                        let i = null !== (l = r[e]) && void 0 !== l ? l : null;
                        if (null !== i && (i.loading ? i.promises.push([a, n]) : i.error ? n(i.error) : a()), null === i) {
                            i = {
                                loading: !0,
                                promises: [
                                    [a, n]
                                ],
                                ready: !1,
                                src: e
                            }, r[e] = i;
                            let l = document.createElement("script");
                            l.src = e, l.async = !0, l.onload = () => {
                                null !== i && (i.loading = !1, i.ready = !0, i.promises.forEach(e => {
                                    let [a] = e;
                                    a()
                                }))
                            }, l.onerror = e => {
                                null !== i && (i.error = e, i.loading = !1, i.promises.forEach(a => {
                                    let [, n] = a;
                                    n(e)
                                }))
                            }, document.body.appendChild(l)
                        }
                    }).then(() => s(!0))
                }, [e]), (0, l.useEffect)(() => {
                    !0 === o && !0 !== d && (null == a || a())
                }, [a, o, d]), o
            }
        },
        36809: function(e, a, n) {
            "use strict";
            var l, i;
            n.d(a, {
                N: function() {
                    return l
                }
            }), (i = l || (l = {})).Dark = "dark", i.Light = "light", i.Gradient = "gradient"
        },
        950: function(e, a, n) {
            "use strict";
            n.d(a, {
                Q8: function() {
                    return r
                },
                SQ: function() {
                    return i
                },
                yv: function() {
                    return u
                }
            });
            var l, i, t = n(58832);

            function r(e, a) {
                return (0, t.Kn)(a) ? a[e] : a
            }

            function u(e) {
                return Object.values(i).includes(e)
            }(l = i || (i = {})).English = "en", l.German = "de", Object.values(i)
        },
        23260: function(e, a, n) {
            "use strict";
            n.d(a, {
                e: function() {
                    return i
                }
            });
            var l = n(58832);

            function i(e, a) {
                return null == e ? null : (0, l.mf)(e) ? e(a) : e
            }
        },
        76474: function(e) {
            e.exports = {
                component: "MarketoForm_component__3U_bC",
                showMessage: "MarketoForm_showMessage__0ehqY",
                form: "MarketoForm_form__aj8B5",
                hasGradientContext: "MarketoForm_hasGradientContext__gYPlv",
                hasBookADemoTemplate: "MarketoForm_hasBookADemoTemplate__C0QLX",
                hasNewsletterTemplate: "MarketoForm_hasNewsletterTemplate__hR8_H"
            }
        },
        12578: function(e) {
            e.exports = {
                component: "LoadingIndicator_component__VHJy_",
                isDark: "LoadingIndicator_isDark__GjF2L",
                isLight: "LoadingIndicator_isLight__f0Azq",
                text: "LoadingIndicator_text__3vIef",
                spinner: "LoadingIndicator_spinner__Gaoca"
            }
        }
    }
]);